package library;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Rectangle;
import java.awt.FlowLayout;
import javax.swing.JButton;
import java.awt.GridLayout;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JTable;

public class main extends JFrame {

	private JPanel contentPane;
	private JTextField maintf;
	private JTable maintable;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					main frame = new main();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public main() {
		setTitle("main");
		setBounds(new Rectangle(0, 0, 800, 600));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 769, 601);
		contentPane = new JPanel();
		contentPane.setBounds(new Rectangle(0, 0, 800, 600));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 40, 741, 27);
		contentPane.add(panel);
		panel.setLayout(new GridLayout(0, 6, 0, 0));
		
		JButton btnNewButton = new JButton("\uB300\uC5EC");
		btnNewButton.setBounds(new Rectangle(0, 0, 0, 20));
		panel.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("\uBC18\uB0A9");
		panel.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("\uD68C\uC6D0\uC815\uBCF4");
		panel.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("\uB3C4\uC11C\uAD00\uB9AC");
		panel.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("\uD1B5\uACC4");
		panel.add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("\uAD00\uB9AC\uC790\uB85C\uADF8\uC778");
		panel.add(btnNewButton_5);
		
		JComboBox maincomboBox = new JComboBox();
		maincomboBox.setBounds(24, 106, 162, 42);
		contentPane.add(maincomboBox);
		
		maintf = new JTextField();
		maintf.setBounds(200, 107, 394, 41);
		contentPane.add(maintf);
		maintf.setColumns(10);
		
		JButton mainsearch = new JButton("\uAC80\uC0C9");
		mainsearch.setBounds(608, 106, 109, 42);
		contentPane.add(mainsearch);
		
		maintable = new JTable();
		maintable.setBounds(24, 173, 693, 369);
		contentPane.add(maintable);
	}
}
