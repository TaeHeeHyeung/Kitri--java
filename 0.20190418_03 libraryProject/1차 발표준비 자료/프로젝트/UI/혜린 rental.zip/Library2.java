package com.kitri.test;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JTextPane;
import javax.swing.JTextArea;
import java.awt.Font;

public class Library2 extends JFrame {

	private JPanel contentPane;
	private JTextField ȸ������;
	private JTextField ��������;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Library2 frame = new Library2();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Library2() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 747, 448);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setBounds(12, 10, 715, 393);
		contentPane.add(lblNewLabel);
		
		ȸ������ = new JTextField();
		ȸ������.setBounds(218, 113, 353, 33);
		contentPane.add(ȸ������);
		ȸ������.setColumns(10);
		
		�������� = new JTextField();
		��������.setColumns(10);
		��������.setBounds(218, 190, 353, 33);
		contentPane.add(��������);
		
		Box verticalBox = Box.createVerticalBox();
		verticalBox.setBounds(140, 181, 82, 33);
		contentPane.add(verticalBoxox_1);
		
		JButton �뿩���ɿ��� = new JButton("\uB300\uC5EC\uAC00\uB2A5\uC5EC\uBD80");
		�뿩���ɿ���.setBounds(602, 113, 113, 81);
		contentPane.add(�뿩���ɿ���);
		
		JButton btnNewButton = new JButton("\uB300\uC5EC");
		btnNewButton.setBounds(474, 305, 97, 47);
		contentPane.add(btnNewButton);
		
		JButton button = new JButton("\uCDE8\uC18C");
		button.setBounds(602, 305, 97, 47);
		contentPane.add(button);
		
		JLabel label = new JLabel("\uD68C\uC6D0\uC815\uBCF4");
		label.setFont(new Font("����", Font.PLAIN, 15));
		label.setBounds(116, 117, 71, 24);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("\uB3C4\uC11C\uC815\uBCF4");
		label_1.setFont(new Font("����", Font.PLAIN, 15));
		label_1.setBounds(116, 194, 56, 24);
		contentPane.add(label_1);
	}
}
