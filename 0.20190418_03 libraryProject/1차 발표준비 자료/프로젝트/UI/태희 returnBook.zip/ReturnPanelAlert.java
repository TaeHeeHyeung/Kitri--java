package com.kitri.project1;

import java.awt.*;

import javax.swing.*;


public class ReturnPanelAlertextends JFrame {

	public JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Page5 frame = new Page5();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ReturnPanelAlert() {
		setBounds(new Rectangle(0, 0, 600, 400));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 600, 400);
		contentPane = new JPanel();
		contentPane.setBounds(new Rectangle(0, 0, 600, 400));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(12, 10, 560, 342);
		contentPane.add(panel);
		panel.setLayout(null);
				
		JLabel lble = new JLabel("<html>�ݳ��� X�� �ʰ��Ǿ����ϴ�.<br>Y�� ���� �뿩�� �Ұ����մϴ�.</html>");
//		Font f= new Font("", Font.BOLD, 20);
//		lble.setFont(f); 
		
		
		lble.setHorizontalAlignment(SwingConstants.CENTER);
		lble.setBounds(155, 115, 279, 79);
		panel.add(lble);
		
		JButton btn_Ok = new JButton("\uD655\uC778");
		btn_Ok.setBounds(238, 309, 97, 23);
		panel.add(btn_Ok);
	}
}
