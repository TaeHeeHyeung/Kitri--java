package com.kitri.project1;

import java.awt.EventQueue;

import javax.swing.*;
import java.awt.Rectangle;

public class ReturnBook extends JFrame {

	JPanel contentPane;
	JTextField txt_member;
	JTextField txt_book_id;
	JButton btn_Cancle;
	JButton btn_Ok;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Page4 frame = new Page4();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ReturnBook() {
		setBounds(new Rectangle(0, 0, 600, 400));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBounds(new Rectangle(0, 0, 600, 400));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(12, 10, 410, 241);
		contentPane.add(panel);
		panel.setLayout(null);
		
		txt_member = new JTextField();
		txt_member.setBounds(133, 70, 226, 21);
		panel.add(txt_member);
		txt_member.setColumns(10);
		
		JLabel label_member_number = new JLabel("\uD68C\uC6D0\uBC88\uD638");
		label_member_number.setBounds(50, 73, 57, 15);
		panel.add(label_member_number);
		
		txt_book_id = new JTextField();
		txt_book_id.setColumns(10);
		txt_book_id.setBounds(133, 131, 226, 21);
		panel.add(txt_book_id);
		
		JLabel label_book_id = new JLabel("\uB3C4\uC11C\uBC88\uD638");
		label_book_id.setBounds(50, 134, 57, 15);
		panel.add(label_book_id);
		
		btn_Ok = new JButton("\uD655\uC778");
		btn_Ok.setBounds(172, 208, 97, 23);
		panel.add(btn_Ok);
		
		btn_Cancle = new JButton("\uCDE8\uC18C");
		btn_Cancle.setBounds(301, 208, 97, 23);
		panel.add(btn_Cancle);
	}
}
