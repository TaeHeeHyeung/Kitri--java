package com.kitri.project1;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;
import javax.swing.table.TableModel;

import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JList;
import javax.swing.JTable;
import javax.swing.JScrollPane;

public class MemberDetail extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MemberDetail frame = new MemberDetail();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MemberDetail() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 500, 526);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(12, 10, 460, 468);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\uC774\uBBF8\uC9C0\uC6A9 \uB77C\uBCA8");
		lblNewLabel.setBorder(new LineBorder(new Color(0, 0, 0)));
		lblNewLabel.setBounds(33, 47, 112, 167);
		panel.add(lblNewLabel);
		
		textField = new JTextField();
		textField.setBounds(268, 97, 142, 21);
		panel.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(268, 146, 142, 21);
		panel.add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(268, 193, 142, 21);
		panel.add(textField_2);
		
		JLabel lblNewLabel_1 = new JLabel("\uD68C\uC6D0\uBA85");
		lblNewLabel_1.setBounds(174, 100, 82, 15);
		panel.add(lblNewLabel_1);
		
		JLabel label = new JLabel("\uD578\uB4DC\uD3F0\uBC88\uD638");
		label.setBounds(174, 149, 82, 15);
		panel.add(label);
		
		JLabel label_1 = new JLabel("\uC8FC\uC18C");
		label_1.setBounds(174, 196, 82, 15);
		panel.add(label_1);
		
		JLabel label_2 = new JLabel("\uD68C\uC6D0\uBC88\uD638");
		label_2.setBounds(174, 55, 82, 15);
		panel.add(label_2);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(268, 52, 142, 21);
		panel.add(textField_3);
		
		JButton btnNewButton = new JButton("\uBCC0\uACBD");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton.setBounds(236, 423, 97, 23);
		panel.add(btnNewButton);
		
		JButton button = new JButton("\uCDE8\uC18C");
		button.setBounds(351, 423, 97, 23);
		panel.add(button);
		
		JLabel label_3 = new JLabel("\uB300\uC5EC\uC911\uC778 \uB3C4\uC11C \uB9AC\uC2A4\uD2B8");
		label_3.setBounds(33, 256, 169, 15);
		panel.add(label_3);
		
		JLabel label_4 = new JLabel("\uD68C\uC6D0\uC0C1\uC138\uC815\uBCF4");
		label_4.setBounds(33, 10, 82, 15);
		panel.add(label_4);
		
		JButton button_1 = new JButton("\uBCC0\uACBD\uC644\uB8CC");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		button_1.setBounds(236, 390, 97, 23);
		panel.add(button_1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(43, 280, 350, 89);
		panel.add(scrollPane);
		
		
		
		table = new JTable(3,2);
		table.add(new JLabel("��1"));
		table.add(new JLabel("��2"));
		table.add(new JLabel("��1"));
		table.add(new JLabel("��2"));
		table.add(new JLabel("��1"));
		table.add(new JLabel("��2"));
		scrollPane.setViewportView(table);
	}
}
